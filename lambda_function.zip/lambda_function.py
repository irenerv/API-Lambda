import json
import pymysql.cursors

#Database Values
endpoint = "database-2.co9miqyu9rwd.us-east-1.rds.amazonaws.com"
username = "admindb"
password = "dbdbdb01!"
db_name = "Music"

# #Connection
connection = pymysql.connect(host=endpoint, user=username, passwd=password, db=db_name, cursorclass=pymysql.cursors.DictCursor)

def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
